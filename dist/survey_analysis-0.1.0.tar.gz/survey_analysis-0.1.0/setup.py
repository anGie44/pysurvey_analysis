import os
from setuptools import setup

setup(version="0.1.0",
	name="survey_analysis",
	description='Survey Statistics',
	url='http://github.com/anGie44/survey_analysis',
	author='anGie44',
	author_email='a.lax4444@gmail.com',
	license='MIT',
	packages=['survey_analysis'],
	zip_safe=False)
