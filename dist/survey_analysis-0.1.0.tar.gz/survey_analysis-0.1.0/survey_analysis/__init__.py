def survey():
	return ("A Survey Package emulating functionality in R's survey Package")

	